Page({
    openGallery: function () {
        this.setData({
            istrue: true
        })
    },
    closeGallery: function () {
        this.setData({
            istrue: false
        })
    }
});
